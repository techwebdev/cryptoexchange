@include('includes.header')

@include('includes.menu')

@yield('content')

@include('includes.footer')