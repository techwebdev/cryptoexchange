<script type="text/javascript">
	var base_url = '<?php echo URL::to('/'); ?>';
</script>
<script src="{{ asset('admin_assets/bower_components/jquery/js/jquery.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script src="{{ asset('admin_assets/bower_components/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('admin_assets/bower_components/popper.js/js/popper.min.js') }}"></script>
<script src="{{ asset('admin_assets/bower_components/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('admin_assets/assets/pages/widget/excanvas.js') }}"></script>

<script src="{{ asset('admin_assets/bower_components/jquery-slimscroll/js/jquery.slimscroll.js') }}"></script>

<script src="{{ asset('admin_assets/bower_components/modernizr/js/modernizr.js') }}"></script>

<script src="{{ asset('admin_assets/assets/js/SmoothScroll.js') }}"></script>
<script src="{{ asset('admin_assets/assets/js/jquery.mCustomScrollbar.concat.min.js') }}"></script>

<script src="{{ asset('admin_assets/bower_components/chart.js/js/Chart.js') }}"></script>
<script src="{{ asset('admin_assets/assets/pages/widget/amchart/amcharts.js') }}"></script>
<script src="{{ asset('admin_assets/assets/pages/widget/amchart/serial.js') }}"></script>
<script src="{{ asset('admin_assets/assets/pages/widget/amchart/light.js') }}"></script>

<script src="{{ asset('admin_assets/assets/js/pcoded.min.js') }}"></script>
<script src="{{ asset('admin_assets/assets/js/dark-light/vertical-layout.min.js') }}"></script>

<script src="{{ asset('admin_assets/bower_components/datatables.net/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('admin_assets/bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('admin_assets/assets/js/toastr.min.js') }}"></script>
<script src="{{ asset('admin_assets/assets/js/custom.js') }}"></script>

<script src="{{ asset('admin_assets/assets/pages/dashboard/custom-dashboard.js') }}"></script>
<script src="{{ asset('admin_assets/assets/js/script.js') }}"></script>
</body>

</html>