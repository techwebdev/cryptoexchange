<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\NewTransactionReceivedEvent;
use App\User;
use App\Raves;
use App\Transaction;
use App\BitcoinPayment;
use App\ExchangeRate;
use Carbon;
use Auth;

class Utills extends Controller
{
    public function index(){
        $users = User::where('is_admin','0')->orderBy('created_at','desc')->with('transaction')->with('transfer')->with('bank_detail')->get();
        return view('admin.users.index',compact('users'));
    }

    /* public function checkPayments(){
    	$payments = BitcoinPayment::where('status','0')->get();
    	// echo "<pre>";print_r($payments);die;
    	if(!empty($payments)){
    		foreach($payments as $val){
    			if($val->status == "0"){
    				$now = Carbon::now();
    				$to = Carbon::parse($val->created_at)->format('Y-m-d H:i:s');
    				$diff = $now->diffInHours($to);
    				if($diff > 24){
    					$delete = BitcoinPayment::find($val->id)->delete();
    				}
    				if($val->receive_amount >= $val->actual_amount){
	    				$update = BitcoinPayment::where('id',$val->id)->update(['status'=>'1']);
	    				$update = Raves::where('bitcoin_id',$val->id)->update(['status'=>'1']);
	    				$delete = BitcoinPayment::find($val->id)->delete();
	    			}else{
	    				$update = BitcoinPayment::where('id',$val->id)->update(['status'=>'0']);
	    			}
    			}
    		}
    	}
    } */

    public function btcPayment(Request $request){
    	$bitcoin = BitcoinPayment::where(['user_id'=>Auth::user()->id,'from_address'=>$request->payto])->first();
    	if(!empty($bitcoin)){
    		$bitcoin->to_address = $request->payUser;
    		$bitcoin->receive_amount = $request->receive_amount;
    		$bitcoin->status = ($request->receive_amount + $bitcoin->receive_amount >= $bitcoin->actual_amount) ? "1" : "0";
    		$update = $bitcoin->save();
    		if($update){
    			$ravePayment = Raves::where(['user_id'=>Auth::user()->id,'bitcoin_id'=>$bitcoin->id])->first();
    			if(!empty($ravePayment)){
    				$ravePayment->amount = $request->receive_amount + $ravePayment->amount;
    				$ravePayment->txn_status = ($request->receive_amount + $ravePayment->actual_amount >= $bitcoin->actual_amount) ? "1" : "0";
    				$ravePayment->updated_at = Carbon::now();
    				$save = $ravePayment->save();
    			}else{
    				$rave = new Raves;
	    			$rave->user_id = Auth::user()->id;
	    			$rave->txn_id = $request->script;
	    			$rave->txn_Ref = $request->hash;
	    			$rave->bitcoin_id = $bitcoin->id;
	    			$rave->txn_flwRef = $bitcoin->order_id;
	    			$rave->currency = session('from_currency');
	    			$rave->amount = $request->receive_amount;
	    			$rave->charges = "0";
	    			$rave->txn_status = ($request->receive_amount >= $bitcoin->actual_amount) ? "1" : "0";
	    			$rave->created_at = Carbon::now();
	    			$save = $rave->save();
    			}
    			if($save){
    				$transactionChk = Transaction::where(['user_id'=>Auth::user()->id,'rave_id'=>$rave->id])->first();
    				if(!empty($transactionChk)){
    					$transferAmountChk = ExchangeRate::where(['from_currency'=>session('from_currency'),'to_currency'=>session('to_currency')])->first();
    					$transactionChk->amount = $request->receive_amount + $transactionChk->amount;
    					$transactionChk->transferAmount = $transferAmountChk->amount + $transactionChk->amount;
    					$transactionChk->status = "0";
    					$transactionChk->updated_at = Carbon::now();
    					$transactionChk->save();
    					event(new NewTransactionReceivedEvent($transactionChk));
    				}else{
    					$transferAmount = ExchangeRate::where(['from_currency'=>$chargeCurrency,'to_currency'=>Session::get('to_currency')])->first();
	    				$transaction = new Transaction;
	    				$transaction->user_id = Auth::user()->id;
	    				$transaction->rave_id = $rave->id;
	    				$transaction->amount = $rave->amount;
	    				$transaction->transferAmount = $transferAmount->amount * $rave->amount;
	    				$transaction->charges = "";
	    				$transaction->from_currency = session('from_currency');
	    				$transaction->to_currency = session('to_currency');
	    				$transaction->status = "0";
	    				$transaction->created_at = Carbon::now();
	    				$transaction->save();
	    				event(new NewTransactionReceivedEvent($transaction));
    				}
    			}
    		}
    	}
    }
}
