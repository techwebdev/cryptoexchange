<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use App\BitcoinPayment;
use App\Raves;
use Carbon;

class CheckPayment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'payment:btc';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check Payement Receive or not.!';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        \Log::info("Cron is Working fine");
        $payments = BitcoinPayment::where('status','0')->get();
        // \Log::info($payments);
    	// echo "<pre>";print_r($payments);die;
    	if(!empty($payments)){
    		foreach($payments as $val){
    			if($val->status == "0"){
    				$now = Carbon::now();
    				$to = Carbon::parse($val->created_at)->format('Y-m-d H:i:s');
    				$diff = $now->diffInHours($to);
    				if($diff > 24){
                        $update = BitcoinPayment::where('id',$val->id)->update(['status'=>'1']);
    					$delete = BitcoinPayment::where('id',$val->id)->delete();
    				}
    				if($val->receive_amount >= $val->actual_amount){
	    				$update = BitcoinPayment::where('id',$val->id)->update(['status'=>'1']);
                        $update = Raves::where('bitcoin_id',$val->id)->update(['txn_status'=>'1']);
                        $file = 'archive-list-'.Carbon::today()->format('d-m-Y').'.csv';
                        $chkFile = \DB::table('files')->where('name',[$file])->first();
                        if(empty($chkFile)){
                            \DB::table('files')->insert(['name'=>$file,'created_at'=>Carbon::now()]);
                        }
                        // dd(file_exists($file));
                        if(\File::exists($file)){
                            // echo "update";die;
                            // File::makeDirectory($backupLoc, 0755, true, true);
                            // \Storage::put($file,$val->from_address, 'public');
                            \Storage::disk('public')->put($file, $val->from_address);
                        }else{
                            // echo "insert";die;
                            \Storage::disk('public')->append($file, $val->from_address);
                            \DB::table('files')->where('name',[$file])->update(['name'=>$file,'updated_at'=>Carbon::now()]);
                        }
                        $delete = BitcoinPayment::where('id',$val->id)->delete();
                        \Log::info("Status Change successfully of address ".$val->from_address);
	    			}else{
                        $update = BitcoinPayment::where('id',$val->id)->update(['status'=>'0']);
                        \Log::info("Status not change successfully of address ".$val->from_address);
	    			}
    			}
    		}
    	}

        $this->info('Payement Cron Cummand Run successfully!');
    }
}
