@include('admin.includes.header')

@include ('admin.includes.sidebar')

@yield('content')

@include('admin.includes.footer')