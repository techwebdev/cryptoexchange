<?php

use Illuminate\Database\Seeder;
use App\ExchangeRate;

class ExchangeRateSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $array = array(
    		['from_currency'=>'NGN','to_currency'=>'PM','amount'=>'50'],
     		['from_currency'=>'NGN','to_currency'=>'BTC','amount'=>'60'],
     		['from_currency'=>'PM','to_currency'=>'BTC','amount'=>'70'],
     		['from_currency'=>'PM','to_currency'=>'NGN','amount'=>'450'],
     		['from_currency'=>'BTC','to_currency'=>'NGN','amount'=>'90'],
     		['from_currency'=>'BTC','to_currency'=>'PM','amount'=>'100'],
         );
        if(!empty($array)){
        	foreach($array as $val){
        		ExchangeRate::create($val);
        	}
        }
    }
}
